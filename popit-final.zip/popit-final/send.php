<?php
// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fname = htmlspecialchars($_POST['fname']);
    $lname = htmlspecialchars($_POST['lname']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);
 
    // Set email parameters
    $to = 'anumeenachandran@gmail.com';  // Change to your email address
    $subject = 'Contact Form Submission';
    $body = "Name: $fname\nLast Name: $lname\nEmail: $email\n\nMessage:\n$message";
    $headers = "From: $email\r\n";
 
    // Send email
    if (mail($to, $subject, $body, $headers)) {
        echo 'Email sent successfully!';
    } else {
        echo 'Failed to send email.';
    }
}
?>